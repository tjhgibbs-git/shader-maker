Additional context test packs, Minecraft Java 26.3 only.
These ZIPs are standalone vanilla resource packs, with no runtime mod or implicit datapack.
The accompanying shader-maker-context-26.3.jar is the Fabric authoring editor only.

Enable one inner ZIP at a time. Each embeds shader-maker-project.json and its own README.
*-screen uses full-screen grading after at least three matching terrain samples.
*-blocks scopes grading to marked solid/cutout terrain pixels.
All matches double exposure; absent/nonmatching inputs leave the grade neutral.
Colours and distance ranges are explicit test values, not automatic biome detection.
Fog ranges are 100..200 blocks; they need not match a normal world's settings.
Lighting: ambient #0A0A0A, block tint #FFD88C, sky colour input #FFFFFF,
night vision colour input #999999. These are raw lighting inputs, not effect-active tests.
Fog target #C0D8FF and terrain vertex target #80CC1A use RGB tolerance 0.01.
Vertex tint includes baked shading: no particular block type is guaranteed to match.

multi.zip tests all four condition bits and installation alongside a zero-strength sky layer.
Its four conditions independently test fog start/end, sky fog end and cloud fog end at 100..200.

491 new Mesa EGL pixel checks, 133 model checks and 586 new ShaderC cases passed.
Minecraft clean-client OpenGL/Vulkan device and overlay/transparency validation is PENDING.
Alpha markers can be removed or mimicked by transparent composition/other packs.
Blocks only is experimental marked terrain, not guaranteed segmentation through glass/water.
See world-signals-research.md for full scope, evidence and the clean-client checklist.
