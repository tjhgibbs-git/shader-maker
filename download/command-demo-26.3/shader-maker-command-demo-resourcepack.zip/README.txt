Shader Maker 0.1 · Minecraft Java 26.3 only.
Full-screen display-referred color grading; ordered layers and camera-height conditions.
Install this ZIP in resourcepacks and enable it.
Applies automatically. Disable this pack to remove it. Other end_of_frame packs compete by priority.
No mod required. Camera height and area conditions follow the vanilla camera each frame. No source images included. OpenGL/Vulkan game validation must be recorded before distribution.

COMMAND-SWITCHED LAYERS (/posteffect)
Each layer below is a separate post effect. It is OFF until a command turns it on for a player, and grades on top of the always-on look.
Needs cheats / operator permission (or a datapack function or command block).
  Desert heat: /posteffect add @s shader_maker:desert_heat   (fade out: /posteffect remove @s shader_maker:desert_heat then /posteffect add @s shader_maker:desert_heat_off)
  Frozen: /posteffect add @s shader_maker:frozen   (fade out: /posteffect remove @s shader_maker:frozen then /posteffect add @s shader_maker:frozen_off)
  Lush: /posteffect add @s shader_maker:lush   (fade out: /posteffect remove @s shader_maker:lush then /posteffect add @s shader_maker:lush_off)
  Underwater: /posteffect add @s shader_maker:underwater   (fade out: /posteffect remove @s shader_maker:underwater then /posteffect add @s shader_maker:underwater_off)
  Deep dark: /posteffect add @s shader_maker:deep_dark   (fade out: /posteffect remove @s shader_maker:deep_dark then /posteffect add @s shader_maker:deep_dark_off)
  Storm: /posteffect add @s shader_maker:storm   (fade out: /posteffect remove @s shader_maker:storm then /posteffect add @s shader_maker:storm_off)
  Village glow: /posteffect add @s shader_maker:village_glow   (fade out: /posteffect remove @s shader_maker:village_glow then /posteffect add @s shader_maker:village_glow_off)
  Danger: /posteffect add @s shader_maker:danger   (fade out: /posteffect remove @s shader_maker:danger then /posteffect add @s shader_maker:danger_off)
  Sepia: /posteffect add @s shader_maker:sepia   (fade out: /posteffect remove @s shader_maker:sepia then /posteffect add @s shader_maker:sepia_off)
  Dream: /posteffect add @s shader_maker:dream   (fade out: /posteffect remove @s shader_maker:dream then /posteffect add @s shader_maker:dream_off)
Turn everything off: /posteffect clear @s. Effects stay on across relogs (saved with the player).
Fades follow game ticks: they pause with the game and do not run under /tick freeze. A window resize or resource reload restarts a fade-in.
The companion datapack (Export datapack) adds /function shader_maker:menu with clickable toggles, plus on/off/toggle functions for command blocks.
