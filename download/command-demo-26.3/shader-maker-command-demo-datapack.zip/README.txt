Shader Maker command helpers (datapack, Java 26.3)
Put this ZIP in <world>/datapacks and the matching resource pack in resourcepacks. Requires cheats / operator permission.
/function shader_maker:menu  - clickable toggles in chat
/function shader_maker:on/<id>, off/<id> (fades out), toggle/<id>, clear
/function shader_maker:give/<id>  - a command block preloaded with the toggle
Run them as a player (execute as <player> run function ...). Effects: shader_maker:desert_heat, shader_maker:frozen, shader_maker:lush, shader_maker:underwater, shader_maker:deep_dark, shader_maker:storm, shader_maker:village_glow, shader_maker:danger, shader_maker:sepia, shader_maker:dream
Biome or structure triggers: in your own tick function, e.g.
  execute as @a[tag=!sm.on.<id>] at @s if biome ~ ~ ~ minecraft:desert run function shader_maker:on/<id>
  execute as @a[tag=sm.on.<id>] at @s unless biome ~ ~ ~ minecraft:desert run function shader_maker:off/<id>
