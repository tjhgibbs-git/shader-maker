posteffect clear @s
tag @s remove sm.on.desert_heat
scoreboard players set @s sm.fade0 0
tag @s remove sm.on.frozen
scoreboard players set @s sm.fade1 0
tag @s remove sm.on.lush
scoreboard players set @s sm.fade2 0
tag @s remove sm.on.underwater
scoreboard players set @s sm.fade3 0
tag @s remove sm.on.deep_dark
scoreboard players set @s sm.fade4 0
tag @s remove sm.on.storm
scoreboard players set @s sm.fade5 0
tag @s remove sm.on.village_glow
scoreboard players set @s sm.fade6 0
tag @s remove sm.on.danger
scoreboard players set @s sm.fade7 0
tag @s remove sm.on.sepia
scoreboard players set @s sm.fade8 0
tag @s remove sm.on.dream
scoreboard players set @s sm.fade9 0
