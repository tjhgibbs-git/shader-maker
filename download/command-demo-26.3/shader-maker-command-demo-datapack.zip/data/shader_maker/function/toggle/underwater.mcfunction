# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:underwater
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/underwater
tag @s remove sm.on.underwater
posteffect add @s shader_maker:underwater_off
scoreboard players set @s sm.fade3 12
