# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:dream
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/dream
tag @s remove sm.on.dream
posteffect add @s shader_maker:dream_off
scoreboard players set @s sm.fade9 62
