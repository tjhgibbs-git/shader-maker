# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:village_glow
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/village_glow
tag @s remove sm.on.village_glow
posteffect add @s shader_maker:village_glow_off
scoreboard players set @s sm.fade6 42
