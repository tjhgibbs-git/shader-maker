# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:sepia
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/sepia
tag @s remove sm.on.sepia
posteffect add @s shader_maker:sepia_off
scoreboard players set @s sm.fade8 22
