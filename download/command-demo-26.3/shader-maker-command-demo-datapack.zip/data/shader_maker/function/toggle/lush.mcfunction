# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:lush
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/lush
tag @s remove sm.on.lush
posteffect add @s shader_maker:lush_off
scoreboard players set @s sm.fade2 42
