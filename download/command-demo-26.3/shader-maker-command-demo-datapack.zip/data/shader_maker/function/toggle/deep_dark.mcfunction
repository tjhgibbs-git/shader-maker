# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:deep_dark
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/deep_dark
tag @s remove sm.on.deep_dark
posteffect add @s shader_maker:deep_dark_off
scoreboard players set @s sm.fade4 62
