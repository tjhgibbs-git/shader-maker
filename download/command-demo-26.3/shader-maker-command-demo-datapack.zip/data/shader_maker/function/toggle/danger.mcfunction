# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:danger
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/danger
tag @s remove sm.on.danger
posteffect add @s shader_maker:danger_off
scoreboard players set @s sm.fade7 8
