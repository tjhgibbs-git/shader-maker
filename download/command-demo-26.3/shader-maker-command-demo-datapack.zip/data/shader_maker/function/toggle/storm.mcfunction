# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:storm
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/storm
tag @s remove sm.on.storm
posteffect add @s shader_maker:storm_off
scoreboard players set @s sm.fade5 82
