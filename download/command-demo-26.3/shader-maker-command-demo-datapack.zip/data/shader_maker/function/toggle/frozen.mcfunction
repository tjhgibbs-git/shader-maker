# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:frozen
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/frozen
tag @s remove sm.on.frozen
posteffect add @s shader_maker:frozen_off
scoreboard players set @s sm.fade1 42
