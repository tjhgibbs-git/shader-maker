# On if it is off, fade out if it is on.
execute store success score @s sm.was_on run posteffect remove @s shader_maker:desert_heat
execute if score @s sm.was_on matches 0 run return run function shader_maker:on/desert_heat
tag @s remove sm.on.desert_heat
posteffect add @s shader_maker:desert_heat_off
scoreboard players set @s sm.fade0 42
