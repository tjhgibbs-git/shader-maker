# A command block that toggles Deep dark for the nearest player. Place it and add a button.
give @s minecraft:command_block[minecraft:custom_name='Toggle Deep dark',minecraft:block_entity_data={id:"minecraft:command_block",Command:"execute as @p run function shader_maker:toggle/deep_dark"}]
