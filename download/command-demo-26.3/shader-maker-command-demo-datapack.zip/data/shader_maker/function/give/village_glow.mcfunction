# A command block that toggles Village glow for the nearest player. Place it and add a button.
give @s minecraft:command_block[minecraft:custom_name='Toggle Village glow',minecraft:block_entity_data={id:"minecraft:command_block",Command:"execute as @p run function shader_maker:toggle/village_glow"}]
