# A command block that toggles Dream for the nearest player. Place it and add a button.
give @s minecraft:command_block[minecraft:custom_name='Toggle Dream',minecraft:block_entity_data={id:"minecraft:command_block",Command:"execute as @p run function shader_maker:toggle/dream"}]
