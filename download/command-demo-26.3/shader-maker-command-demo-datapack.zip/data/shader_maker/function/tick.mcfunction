# Remove finished fade-out effects so they stop costing a pass.
execute as @a[scores={sm.fade0=1}] run posteffect remove @s shader_maker:desert_heat_off
scoreboard players remove @a[scores={sm.fade0=1..}] sm.fade0 1
execute as @a[scores={sm.fade1=1}] run posteffect remove @s shader_maker:frozen_off
scoreboard players remove @a[scores={sm.fade1=1..}] sm.fade1 1
execute as @a[scores={sm.fade2=1}] run posteffect remove @s shader_maker:lush_off
scoreboard players remove @a[scores={sm.fade2=1..}] sm.fade2 1
execute as @a[scores={sm.fade3=1}] run posteffect remove @s shader_maker:underwater_off
scoreboard players remove @a[scores={sm.fade3=1..}] sm.fade3 1
execute as @a[scores={sm.fade4=1}] run posteffect remove @s shader_maker:deep_dark_off
scoreboard players remove @a[scores={sm.fade4=1..}] sm.fade4 1
execute as @a[scores={sm.fade5=1}] run posteffect remove @s shader_maker:storm_off
scoreboard players remove @a[scores={sm.fade5=1..}] sm.fade5 1
execute as @a[scores={sm.fade6=1}] run posteffect remove @s shader_maker:village_glow_off
scoreboard players remove @a[scores={sm.fade6=1..}] sm.fade6 1
execute as @a[scores={sm.fade7=1}] run posteffect remove @s shader_maker:danger_off
scoreboard players remove @a[scores={sm.fade7=1..}] sm.fade7 1
execute as @a[scores={sm.fade8=1}] run posteffect remove @s shader_maker:sepia_off
scoreboard players remove @a[scores={sm.fade8=1..}] sm.fade8 1
execute as @a[scores={sm.fade9=1}] run posteffect remove @s shader_maker:dream_off
scoreboard players remove @a[scores={sm.fade9=1..}] sm.fade9 1
