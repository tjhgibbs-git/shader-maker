# Fade Lush out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.lush
execute store success score @s sm.was_on run posteffect remove @s shader_maker:lush
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:lush_off
scoreboard players set @s sm.fade2 42
