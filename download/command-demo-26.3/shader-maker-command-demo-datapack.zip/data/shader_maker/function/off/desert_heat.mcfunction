# Fade Desert heat out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.desert_heat
execute store success score @s sm.was_on run posteffect remove @s shader_maker:desert_heat
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:desert_heat_off
scoreboard players set @s sm.fade0 42
