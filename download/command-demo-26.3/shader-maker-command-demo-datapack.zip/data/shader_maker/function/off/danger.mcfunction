# Fade Danger out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.danger
execute store success score @s sm.was_on run posteffect remove @s shader_maker:danger
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:danger_off
scoreboard players set @s sm.fade7 8
