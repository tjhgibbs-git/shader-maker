# Fade Frozen out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.frozen
execute store success score @s sm.was_on run posteffect remove @s shader_maker:frozen
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:frozen_off
scoreboard players set @s sm.fade1 42
