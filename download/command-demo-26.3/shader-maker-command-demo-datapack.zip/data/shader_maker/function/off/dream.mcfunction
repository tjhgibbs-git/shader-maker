# Fade Dream out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.dream
execute store success score @s sm.was_on run posteffect remove @s shader_maker:dream
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:dream_off
scoreboard players set @s sm.fade9 62
