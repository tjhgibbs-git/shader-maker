# Fade Village glow out (if it is on), then remove its fade-out effect.
tag @s remove sm.on.village_glow
execute store success score @s sm.was_on run posteffect remove @s shader_maker:village_glow
execute if score @s sm.was_on matches 0 run return 0
posteffect add @s shader_maker:village_glow_off
scoreboard players set @s sm.fade6 42
