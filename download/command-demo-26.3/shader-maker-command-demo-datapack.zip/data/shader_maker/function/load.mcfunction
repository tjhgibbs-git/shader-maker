scoreboard objectives add sm.was_on dummy
# Fade-out timers, one per command layer (ticks remaining).
scoreboard objectives add sm.fade0 dummy
scoreboard objectives add sm.fade1 dummy
scoreboard objectives add sm.fade2 dummy
scoreboard objectives add sm.fade3 dummy
scoreboard objectives add sm.fade4 dummy
scoreboard objectives add sm.fade5 dummy
scoreboard objectives add sm.fade6 dummy
scoreboard objectives add sm.fade7 dummy
scoreboard objectives add sm.fade8 dummy
scoreboard objectives add sm.fade9 dummy
