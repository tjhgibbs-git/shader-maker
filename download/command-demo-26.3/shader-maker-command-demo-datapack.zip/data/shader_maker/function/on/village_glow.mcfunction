# Fade Village glow in for the executing player.
posteffect remove @s shader_maker:village_glow_off
scoreboard players set @s sm.fade6 0
posteffect add @s shader_maker:village_glow
tag @s add sm.on.village_glow
