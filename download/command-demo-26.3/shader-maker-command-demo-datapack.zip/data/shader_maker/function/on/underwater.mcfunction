# Fade Underwater in for the executing player.
posteffect remove @s shader_maker:underwater_off
scoreboard players set @s sm.fade3 0
posteffect add @s shader_maker:underwater
tag @s add sm.on.underwater
