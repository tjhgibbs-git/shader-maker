# Fade Desert heat in for the executing player.
posteffect remove @s shader_maker:desert_heat_off
scoreboard players set @s sm.fade0 0
posteffect add @s shader_maker:desert_heat
tag @s add sm.on.desert_heat
