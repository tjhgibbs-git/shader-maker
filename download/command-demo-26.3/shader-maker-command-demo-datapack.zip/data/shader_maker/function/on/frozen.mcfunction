# Fade Frozen in for the executing player.
posteffect remove @s shader_maker:frozen_off
scoreboard players set @s sm.fade1 0
posteffect add @s shader_maker:frozen
tag @s add sm.on.frozen
