# Fade Danger in for the executing player.
posteffect remove @s shader_maker:danger_off
scoreboard players set @s sm.fade7 0
posteffect add @s shader_maker:danger
tag @s add sm.on.danger
