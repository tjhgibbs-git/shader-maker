# Fade Sepia in for the executing player.
posteffect remove @s shader_maker:sepia_off
scoreboard players set @s sm.fade8 0
posteffect add @s shader_maker:sepia
tag @s add sm.on.sepia
