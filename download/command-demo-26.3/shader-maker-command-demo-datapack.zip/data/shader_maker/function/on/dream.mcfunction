# Fade Dream in for the executing player.
posteffect remove @s shader_maker:dream_off
scoreboard players set @s sm.fade9 0
posteffect add @s shader_maker:dream
tag @s add sm.on.dream
