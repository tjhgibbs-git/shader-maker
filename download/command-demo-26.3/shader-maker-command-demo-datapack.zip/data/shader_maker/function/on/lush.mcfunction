# Fade Lush in for the executing player.
posteffect remove @s shader_maker:lush_off
scoreboard players set @s sm.fade2 0
posteffect add @s shader_maker:lush
tag @s add sm.on.lush
