# Fade Storm in for the executing player.
posteffect remove @s shader_maker:storm_off
scoreboard players set @s sm.fade5 0
posteffect add @s shader_maker:storm
tag @s add sm.on.storm
