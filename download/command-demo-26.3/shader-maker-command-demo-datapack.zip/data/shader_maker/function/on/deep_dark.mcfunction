# Fade Deep dark in for the executing player.
posteffect remove @s shader_maker:deep_dark_off
scoreboard players set @s sm.fade4 0
posteffect add @s shader_maker:deep_dark
tag @s add sm.on.deep_dark
