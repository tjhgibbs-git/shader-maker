tellraw @s {"text":"── Shader Maker /posteffect demo ──","color":"aqua"}
tellraw @s [{"text":"Automatic: ","color":"gray"},{"text":"[On]","color":"green","click_event":{"action":"run_command","command":"/function shader_maker_demo:auto_on"},"hover_event":{"action":"show_text","value":"Looks follow biome, water, depth, weather, villages and low health"}},{"text":" "},{"text":"[Off]","color":"red","click_event":{"action":"run_command","command":"/function shader_maker_demo:auto_off"},"hover_event":{"action":"show_text","value":"Manual mode: clears looks and stops automatic switching"}}]
tellraw @s {"text":"Manual toggles (best with Automatic off):","color":"gray"}
function shader_maker:menu
tellraw @s [{"text":"Command blocks: ","color":"gray"},{"text":"[Give Sepia toggle block]","color":"gold","click_event":{"action":"run_command","command":"/function shader_maker:give/sepia"}}]
