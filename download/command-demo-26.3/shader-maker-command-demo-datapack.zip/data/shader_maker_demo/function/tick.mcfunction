# Automatic looks from exact server-side checks. Players tagged smd.manual are skipped.
execute as @a[tag=!smd.manual,tag=!smd.auto.desert_heat] at @s if biome ~ ~ ~ #shader_maker_demo:hot run function shader_maker:on/desert_heat
execute as @a[tag=!smd.manual,tag=!smd.auto.desert_heat] at @s if biome ~ ~ ~ #shader_maker_demo:hot run tag @s add smd.auto.desert_heat
execute as @a[tag=!smd.manual,tag=smd.auto.desert_heat] at @s unless biome ~ ~ ~ #shader_maker_demo:hot run function shader_maker:off/desert_heat
execute as @a[tag=!smd.manual,tag=smd.auto.desert_heat] at @s unless biome ~ ~ ~ #shader_maker_demo:hot run tag @s remove smd.auto.desert_heat
execute as @a[tag=!smd.manual,tag=!smd.auto.frozen] at @s if biome ~ ~ ~ #shader_maker_demo:cold run function shader_maker:on/frozen
execute as @a[tag=!smd.manual,tag=!smd.auto.frozen] at @s if biome ~ ~ ~ #shader_maker_demo:cold run tag @s add smd.auto.frozen
execute as @a[tag=!smd.manual,tag=smd.auto.frozen] at @s unless biome ~ ~ ~ #shader_maker_demo:cold run function shader_maker:off/frozen
execute as @a[tag=!smd.manual,tag=smd.auto.frozen] at @s unless biome ~ ~ ~ #shader_maker_demo:cold run tag @s remove smd.auto.frozen
execute as @a[tag=!smd.manual,tag=!smd.auto.lush] at @s if biome ~ ~ ~ #shader_maker_demo:lush run function shader_maker:on/lush
execute as @a[tag=!smd.manual,tag=!smd.auto.lush] at @s if biome ~ ~ ~ #shader_maker_demo:lush run tag @s add smd.auto.lush
execute as @a[tag=!smd.manual,tag=smd.auto.lush] at @s unless biome ~ ~ ~ #shader_maker_demo:lush run function shader_maker:off/lush
execute as @a[tag=!smd.manual,tag=smd.auto.lush] at @s unless biome ~ ~ ~ #shader_maker_demo:lush run tag @s remove smd.auto.lush
execute as @a[tag=!smd.manual,tag=!smd.auto.underwater] at @s anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:water run function shader_maker:on/underwater
execute as @a[tag=!smd.manual,tag=!smd.auto.underwater] at @s anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:water run tag @s add smd.auto.underwater
execute as @a[tag=!smd.manual,tag=smd.auto.underwater] at @s anchored eyes positioned ^ ^ ^ unless block ~ ~ ~ minecraft:water run function shader_maker:off/underwater
execute as @a[tag=!smd.manual,tag=smd.auto.underwater] at @s anchored eyes positioned ^ ^ ^ unless block ~ ~ ~ minecraft:water run tag @s remove smd.auto.underwater
execute as @a[tag=!smd.manual,tag=!smd.auto.deep_dark] at @s if entity @s[y=-128,dy=128] run function shader_maker:on/deep_dark
execute as @a[tag=!smd.manual,tag=!smd.auto.deep_dark] at @s if entity @s[y=-128,dy=128] run tag @s add smd.auto.deep_dark
execute as @a[tag=!smd.manual,tag=smd.auto.deep_dark] at @s unless entity @s[y=-128,dy=128] run function shader_maker:off/deep_dark
execute as @a[tag=!smd.manual,tag=smd.auto.deep_dark] at @s unless entity @s[y=-128,dy=128] run tag @s remove smd.auto.deep_dark
execute as @a[tag=!smd.manual,tag=!smd.auto.storm] at @s if predicate shader_maker_demo:storm run function shader_maker:on/storm
execute as @a[tag=!smd.manual,tag=!smd.auto.storm] at @s if predicate shader_maker_demo:storm run tag @s add smd.auto.storm
execute as @a[tag=!smd.manual,tag=smd.auto.storm] at @s unless predicate shader_maker_demo:storm run function shader_maker:off/storm
execute as @a[tag=!smd.manual,tag=smd.auto.storm] at @s unless predicate shader_maker_demo:storm run tag @s remove smd.auto.storm
execute as @a[tag=!smd.manual,tag=!smd.auto.village_glow] at @s if predicate shader_maker_demo:in_village run function shader_maker:on/village_glow
execute as @a[tag=!smd.manual,tag=!smd.auto.village_glow] at @s if predicate shader_maker_demo:in_village run tag @s add smd.auto.village_glow
execute as @a[tag=!smd.manual,tag=smd.auto.village_glow] at @s unless predicate shader_maker_demo:in_village run function shader_maker:off/village_glow
execute as @a[tag=!smd.manual,tag=smd.auto.village_glow] at @s unless predicate shader_maker_demo:in_village run tag @s remove smd.auto.village_glow
execute as @a[tag=!smd.manual,tag=!smd.auto.danger] at @s if entity @s[scores={smd.hp=..6}] run function shader_maker:on/danger
execute as @a[tag=!smd.manual,tag=!smd.auto.danger] at @s if entity @s[scores={smd.hp=..6}] run tag @s add smd.auto.danger
execute as @a[tag=!smd.manual,tag=smd.auto.danger] at @s unless entity @s[scores={smd.hp=..6}] run function shader_maker:off/danger
execute as @a[tag=!smd.manual,tag=smd.auto.danger] at @s unless entity @s[scores={smd.hp=..6}] run tag @s remove smd.auto.danger
