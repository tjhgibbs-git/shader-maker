tag @s add smd.manual
tag @s remove smd.auto.desert_heat
tag @s remove smd.auto.frozen
tag @s remove smd.auto.lush
tag @s remove smd.auto.underwater
tag @s remove smd.auto.deep_dark
tag @s remove smd.auto.storm
tag @s remove smd.auto.village_glow
tag @s remove smd.auto.danger
function shader_maker:clear
tellraw @s {"text":"Automatic looks off. Use the toggles.","color":"yellow"}
