scoreboard objectives add smd.hp health
tellraw @a [{"text":"Shader Maker demo loaded. ","color":"aqua"},{"text":"[Open menu]","color":"gold","click_event":{"action":"run_command","command":"/function shader_maker_demo:menu"}}]
