tag @s remove smd.manual
tag @s remove smd.auto.desert_heat
tag @s remove smd.auto.frozen
tag @s remove smd.auto.lush
tag @s remove smd.auto.underwater
tag @s remove smd.auto.deep_dark
tag @s remove smd.auto.storm
tag @s remove smd.auto.village_glow
tag @s remove smd.auto.danger
tellraw @s {"text":"Automatic looks on. Looks you toggle by hand stay until you toggle them again.","color":"green"}
