#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 0) out vec4 fragColor;
float visualBiomeCode(vec3 c) {
    float peak = max(c.r, max(c.g,c.b));
    if (peak < 0.06) return 0.0;
    c /= peak;
    float best = 0.000001; float code = 0.0; float d;
    d = distance(c, vec3(1.0, 0.5019607843137255, 0.25098039215686274)); d *= d;
    if (d < best) {best=d; code=15.0;}
    return code;
}
void main() {
    // Preserve vanilla visible RGB, including fog and the lower dark disc.
    fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance,
        0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
    float code = visualBiomeCode(ColorModulator.rgb);
    if (code > 0.0 && ColorModulator.a == 1.0) fragColor.a = code / 255.0;
}
