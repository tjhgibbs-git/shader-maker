Shader Maker 0.1 · Minecraft Java 26.3 only.
Full-screen display-referred color grading; ordered layers and camera-height conditions.
Install this ZIP in resourcepacks and enable it.
Applies automatically. Disable this pack to remove it. Other end_of_frame packs compete by priority.
No mod required. Camera-height conditions follow the vanilla camera each frame. No source images included. OpenGL/Vulkan game validation must be recorded before distribution.

SKY COLOUR CONTEXT
Sky colour signal, not biome identity. Datapacks can set the sky colour to drive this condition. Matching uses normalized RGB hue, not brightness; darkness, weather, blending and overlays can suppress or change the visible signal. Requires visible sky; no signal means inactive.
This version senses normalized sky colour, not biome IDs. Set minecraft:visual/sky_color in a datapack to drive a custom signal. A 32x32 sample grid needs at least three unoccluded matching sky samples. Look away from the sky or lose its signal and the layer becomes inactive. Blended borders, darkness, immersion, overlays and other shader packs can suppress or change detection.
Overrides assets/minecraft/shaders/core/sky.fsh; reserves opaque sky alpha as a signal, leaving its RGB unchanged. The post pass restores recognized sky alpha to 1. Core overrides also load in Command mode, even before command activation, and conflict with other sky overrides or uses of framebuffer alpha. No client runtime dependency. Minecraft OpenGL/Vulkan validation is still pending.
Custom sky signal: custom_ff8040 = 
