Shader Maker 0.1 · Minecraft Java 26.3 only.
Full-screen display-referred color grading; ordered layers and camera-height conditions.
Install this ZIP in resourcepacks and enable it.
Applies automatically. Disable this pack to remove it. Other end_of_frame packs compete by priority.
No mod required. Camera-height conditions follow the vanilla camera each frame. No source images included. OpenGL/Vulkan game validation must be recorded before distribution.

EXPERIMENTAL VISUAL BIOME DETECTION
Visual detection, not exact biome IDs. Datapacks/resource packs that change sky colors can change or break matches. Weather, time, blending and custom dimensions can also change matches. Requires visible sky; no signal means inactive.
This version senses sky color, not fog or exact IDs. A 32x32 sample grid needs at least three unoccluded matching sky samples. Look away from the sky or lose its signal and the layer becomes inactive. Blended borders, darkness, immersion, overlays and other shader packs can suppress or change detection.
Overrides assets/minecraft/shaders/core/sky.fsh; reserves opaque sky alpha as a signal, leaving its RGB unchanged. The post pass restores recognized sky alpha to 1. Core overrides also load in Command mode, even before command activation, and conflict with other sky overrides or uses of framebuffer alpha. No client runtime dependency. Minecraft OpenGL/Vulkan validation is still pending.
Visual test: sky_78a7ff = minecraft:beach, minecraft:deep_dark, minecraft:dripstone_caves, minecraft:mangrove_swamp, minecraft:plains, minecraft:sulfur_caves, minecraft:sunflower_plains, minecraft:swamp
