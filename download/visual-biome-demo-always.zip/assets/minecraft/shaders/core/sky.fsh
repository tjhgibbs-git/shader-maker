#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 0) out vec4 fragColor;
float visualBiomeCode(vec3 c) {
    float peak = max(c.r, max(c.g,c.b));
    if (peak < 0.06) return 0.0;
    c /= peak;
    float best = 0.000001; float code = 0.0; float d;
    d = distance(c, vec3(0.43137254901960786, 0.6941176470588235, 1.0)); d *= d;
    if (d < best) {best=d; code=15.0;}
    d = distance(c, vec3(0.4627450980392157, 0.6588235294117647, 1.0)); d *= d;
    if (d < best) {best=d; code=30.0;}
    d = distance(c, vec3(0.4666666666666667, 0.6588235294117647, 1.0)); d *= d;
    if (d < best) {best=d; code=45.0;}
    d = distance(c, vec3(0.47058823529411764, 0.6549019607843137, 1.0)); d *= d;
    if (d < best) {best=d; code=60.0;}
    d = distance(c, vec3(0.4745098039215686, 0.6509803921568628, 1.0)); d *= d;
    if (d < best) {best=d; code=75.0;}
    d = distance(c, vec3(0.47843137254901963, 0.6470588235294118, 1.0)); d *= d;
    if (d < best) {best=d; code=90.0;}
    d = distance(c, vec3(0.4823529411764706, 0.6431372549019608, 1.0)); d *= d;
    if (d < best) {best=d; code=105.0;}
    d = distance(c, vec3(0.48627450980392156, 0.6392156862745098, 1.0)); d *= d;
    if (d < best) {best=d; code=120.0;}
    d = distance(c, vec3(0.49019607843137253, 0.6352941176470588, 1.0)); d *= d;
    if (d < best) {best=d; code=135.0;}
    d = distance(c, vec3(0.49019607843137253, 0.6392156862745098, 1.0)); d *= d;
    if (d < best) {best=d; code=150.0;}
    d = distance(c, vec3(0.4980392156862745, 0.6313725490196078, 1.0)); d *= d;
    if (d < best) {best=d; code=165.0;}
    d = distance(c, vec3(0.5058823529411764, 0.6274509803921569, 1.0)); d *= d;
    if (d < best) {best=d; code=180.0;}
    d = distance(c, vec3(0.5098039215686274, 0.6235294117647059, 1.0)); d *= d;
    if (d < best) {best=d; code=195.0;}
    d = distance(c, vec3(0.5137254901960784, 0.6196078431372549, 1.0)); d *= d;
    if (d < best) {best=d; code=210.0;}
    d = distance(c, vec3(0.5215686274509804, 0.615686274509804, 1.0)); d *= d;
    if (d < best) {best=d; code=225.0;}
    d = distance(c, vec3(1.0, 1.0, 1.0)); d *= d;
    if (d < best) {best=d; code=240.0;}
    return code;
}
void main() {
    // Preserve vanilla visible RGB, including fog and the lower dark disc.
    fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance,
        0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
    float code = visualBiomeCode(ColorModulator.rgb);
    if (code > 0.0 && ColorModulator.a == 1.0) fragColor.a = code / 255.0;
}
