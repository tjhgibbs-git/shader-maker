#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
uniform sampler2D PrevSampler;
layout(std140) uniform CommandFade {
    float FadeOut;
    float FadeTicks;
};
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
vec3 smPack24(float v) {
    float n = floor(clamp(v, 0.0, 1.0) * 16777215.0 + 0.5);
    float r = floor(n / 65536.0);
    float g = floor((n - r * 65536.0) / 256.0);
    return vec3(r, g, n - r * 65536.0 - g * 256.0) / 255.0;
}
float smUnpack24(vec3 c) {
    vec3 b = floor(c * 255.0 + 0.5);
    return (b.r * 65536.0 + b.g * 256.0 + b.b) / 16777215.0;
}
vec2 smPack16(float v) {
    float n = floor(clamp(v, 0.0, 1.0) * 65535.0 + 0.5);
    float hi = floor(n / 256.0);
    return vec2(hi, n - hi * 256.0) / 255.0;
}
float smUnpack16(vec2 c) {
    vec2 b = floor(c * 255.0 + 0.5);
    return (b.x * 256.0 + b.y) / 65535.0;
}
/** Raw game ticks since a stored time, modulo the 24000-tick GameTime cycle. */
float smSinceTicks(vec4 clock) { return fract(GameTime - smUnpack24(clock.rgb) + 1.0) * 24000.0; }
/** Per-frame step for held memory: 0 if uninitialised or apparently negative. */
float smElapsedTicks(vec4 clock) {
    if (clock.a < 0.5) return 0.0;
    float dt = fract(GameTime - smUnpack24(clock.rgb) + 1.0) * 24000.0;
    return dt > 12000.0 ? 0.0 : dt;
}
void main() {
    vec4 prev = texelFetch(PrevSampler, ivec2(0), 0);
    if (prev.a < 0.5) fragColor = vec4(smPack24(GameTime), 0.6);
    else if (prev.a < 0.9 && smSinceTicks(prev) >= FadeTicks) fragColor = vec4(prev.rgb, 1.0);
    else fragColor = prev;
}
