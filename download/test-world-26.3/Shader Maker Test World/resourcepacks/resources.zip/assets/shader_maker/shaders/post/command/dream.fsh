#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>
uniform sampler2D InSampler;
uniform sampler2D ClockSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform CommandFade {
    float FadeOut;
    float FadeTicks;
};
vec3 smPack24(float v) {
    float n = floor(clamp(v, 0.0, 1.0) * 16777215.0 + 0.5);
    float r = floor(n / 65536.0);
    float g = floor((n - r * 65536.0) / 256.0);
    return vec3(r, g, n - r * 65536.0 - g * 256.0) / 255.0;
}
float smUnpack24(vec3 c) {
    vec3 b = floor(c * 255.0 + 0.5);
    return (b.r * 65536.0 + b.g * 256.0 + b.b) / 16777215.0;
}
vec2 smPack16(float v) {
    float n = floor(clamp(v, 0.0, 1.0) * 65535.0 + 0.5);
    float hi = floor(n / 256.0);
    return vec2(hi, n - hi * 256.0) / 255.0;
}
float smUnpack16(vec2 c) {
    vec2 b = floor(c * 255.0 + 0.5);
    return (b.x * 256.0 + b.y) / 65535.0;
}
/** Raw game ticks since a stored time, modulo the 24000-tick GameTime cycle. */
float smSinceTicks(vec4 clock) { return fract(GameTime - smUnpack24(clock.rgb) + 1.0) * 24000.0; }
/** Per-frame step for held memory: 0 if uninitialised or apparently negative. */
float smElapsedTicks(vec4 clock) {
    if (clock.a < 0.5) return 0.0;
    float dt = fract(GameTime - smUnpack24(clock.rgb) + 1.0) * 24000.0;
    return dt > 12000.0 ? 0.0 : dt;
}
float smCommandFade(vec4 clock) {
    float progress = FadeTicks <= 0.0 || clock.a > 0.9 ? 1.0
        : smoothstep(0.0, 1.0, clamp(smSinceTicks(clock) / FadeTicks, 0.0, 1.0));
    return FadeOut > 0.5 ? 1.0 - progress : progress;
}
float curve_layer_master(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_layer_red(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_layer_green(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_layer_blue(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}

vec3 levels_layer(vec3 c) {
    c = max(vec3(0.0), (c * exp2(0.35) - 0.0) / (1.0 - 0.0));
    vec3 soft = mix(c, vec3(0.75) + 0.25 * (1.0 - exp(-(c - 0.75) / 0.25)), greaterThan(c, vec3(0.75)));
    c = mix(c, soft, 0.8);
    return clamp((pow(clamp(c, 0.0, 1.0), vec3(1.0 / 1.0)) - 0.5) * 0.8 + 0.5, 0.0, 1.0);
}
vec3 grade_layer(vec3 source) {
    vec3 c = levels_layer(source);
    c = vec3(curve_layer_red(curve_layer_master(c.r)), curve_layer_green(curve_layer_master(c.g)), curve_layer_blue(curve_layer_master(c.b)));
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float chroma = max(max(c.r,c.g),c.b) - min(min(c.r,c.g),c.b);
    float sat = 1.0 * (1.0 + 0.5 * (1.0 - chroma));
    float edge = clamp(length(texCoord * 2.0 - 1.0) / sqrt(2.0), 0.0, 1.0);
    float shade = 1.0 - 0.3 * edge * edge;
    c = clamp((vec3(luma) + (c - luma) * sat) * vec3(1.0,1.0,1.0) * shade, 0.0, 1.0);
    return mix(source, c, 1.0);
}
void main() {
    vec4 source = texture(InSampler, texCoord);
    float cameraY = float(CameraBlockPos.y) - CameraOffset.y;
    float cameraX = float(CameraBlockPos.x) - CameraOffset.x;
    float cameraZ = float(CameraBlockPos.z) - CameraOffset.z;
    float weight = 1.0 * smCommandFade(texelFetch(ClockSampler, ivec2(0), 0));
    fragColor = vec4(mix(source.rgb, grade_layer(source.rgb), clamp(weight, 0.0, 1.0)), source.a);
}
