execute as @a[tag=!smt.started] run function shader_maker_test:start
