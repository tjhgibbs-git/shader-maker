tag @s add smt.started
posteffect clear @s
function shader_maker:clear
tp @s -112 90 -540 0 0
function shader_maker_test:book
tellraw @s {"text":"Shader Maker test world: read the book in your inventory.","color":"aqua"}
