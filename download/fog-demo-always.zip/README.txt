Shader Maker 0.1 · Minecraft Java 26.3 only.
Full-screen display-referred color grading; ordered layers and camera-height conditions.
Install this ZIP in resourcepacks and enable it.
Applies automatically. Disable this pack to remove it. Other end_of_frame packs compete by priority.
No mod required. Camera-height conditions follow the vanilla camera each frame. No source images included. OpenGL/Vulkan game validation must be recorded before distribution.

AUTHORED TERRAIN FOG (26.3 experimental)
Adds distance/height/volume fog to terrain, including native terrain colour variants. Entities, block entities, particles, sky, clouds and hand keep native fog. Minecraft device/OIT testing is pending.
Uses the resolved native FogColor, including datapack environment changes. No datapack is required. Native environmental/status/boundary fog remains after the authored medium; post grades affect both.
Overrides core/terrain.vsh and core/terrain.fsh. All active media add optical depth; ordering does not change the result. Disable the resource pack to remove fog.
