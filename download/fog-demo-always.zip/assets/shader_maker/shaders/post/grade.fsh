#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
float curve_base_master(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_base_red(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_base_green(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}
float curve_base_blue(float x) { x = clamp(x, 0.0, 1.0);
{ float t = (x - 0.0) / 1.0; return clamp(((0.0 * t + 0.0) * t + 1.0) * t + 0.0, 0.0, 1.0); }
}

vec3 levels_base(vec3 c) {
    c = max(vec3(0.0), (c * exp2(0.0) - 0.0) / (1.0 - 0.0));
    vec3 soft = mix(c, vec3(0.75) + 0.25 * (1.0 - exp(-(c - 0.75) / 0.25)), greaterThan(c, vec3(0.75)));
    c = mix(c, soft, 0.0);
    return clamp((pow(clamp(c, 0.0, 1.0), vec3(1.0 / 1.0)) - 0.5) * 1.0 + 0.5, 0.0, 1.0);
}
vec3 grade_base(vec3 source) {
    vec3 c = levels_base(source);
    c = vec3(curve_base_red(curve_base_master(c.r)), curve_base_green(curve_base_master(c.g)), curve_base_blue(curve_base_master(c.b)));
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float chroma = max(max(c.r,c.g),c.b) - min(min(c.r,c.g),c.b);
    float sat = 1.0 * (1.0 + 0.0 * (1.0 - chroma));
    float edge = clamp(length(texCoord * 2.0 - 1.0) / sqrt(2.0), 0.0, 1.0);
    float shade = 1.0 - 0.0 * edge * edge;
    c = clamp((vec3(luma) + (c - luma) * sat) * vec3(1.0,1.0,1.0) * shade, 0.0, 1.0);
    return mix(source, c, 1.0);
}
void main() {
    vec4 source = texture(InSampler, texCoord);
    vec3 result = grade_base(source.rgb);
    fragColor = vec4(result, source.a);
}
